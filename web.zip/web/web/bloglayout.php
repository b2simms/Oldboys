<head>
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  
  <script src="jquery-2.1.4.min.js"></script>
  
  <link type='text/css' title='standard' rel='stylesheet' href='blogstyle.css' />
</head>

<body class="en" >

    <div id="page">
        <h1>The Ratio Revolution Will Not Be Televised</h1>
        <div class="entry">
            <h2>Anyone else tired of Helvetica?</h2>
            <h3 class="info">A <a href="#">Blog</a> Entry:</h3>
            <div class="content">
                <div class="main">
                    <p>I mean it: I’ve got your Neue Haas Grotesk right here, buddy. Along with some lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

Yeah, you heard me.

Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                </div><!-- /end .content -->
                <div class="meta">
                    <p>Posted on 15 February 2009. 15 comments so far.</p>
                    <p>Tagged with rants, typography, filler copy, sunshine and puppies.</p>
                </div><!-- /end .meta -->
            </div><!-- /end .main -->
        </div><!-- /end .entry -->
    </div><!-- /end #page -->
</body>    